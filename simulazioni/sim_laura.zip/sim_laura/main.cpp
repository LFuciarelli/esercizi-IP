#include <iostream>
#include "header.h"

using namespace std;

int main(){
	try{
		queue q1;
		create_queue(q1);

		Persona l;
		l.nome = "Laura";
		l.cognome = "Fuciarelli";
		l.anno_nascita = 2001;
		
		Persona i;
		i.nome = "Isaac";
		i.cognome = "Newton";
		i.anno_nascita = 1600;
		
		Persona a;
		a.nome = "Alan";
		a.cognome = "Turing";
		a.anno_nascita = 1912;
		
		enqueue(q1, l);
		enqueue(q1, i);
		enqueue(q1, a);

		//cout << eta(l) << endl;
		sort_queue(q1);
		print(q1);
		dequeue(q1);
	} catch(string s){
		cerr << s << endl;
	}
}
